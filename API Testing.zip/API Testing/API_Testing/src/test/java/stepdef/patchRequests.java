package stepdef;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import Utilities.configReader;

public class patchRequests 
{
    private RequestSpecification request;
    private Response response;
    private configReader config = new configReader(); 
    
    // Common setup for all scenarios: Define API endpoint
    @Given("API endpoint {string}")
    public void api_endpoint(String dynamicId) 
    {       
        String baseUrl = config.getProperty("baseUrl"); 
        RestAssured.useRelaxedHTTPSValidation(); // Ignore SSL validation
        request = given().baseUri(baseUrl + dynamicId); 
    }

    // Common step: Send PATCH request with payload   
    @When("I send a PATCH request with the following payload:")
    public void i_send_a_patch_request_with_the_following_payload(String payload) 
    {
        response = request.header("Content-Type", "application/json") 
                         .body(payload)
                         .patch();
    }

    // Common validation step: Check response status code
    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(Integer statusCode) 
    {
        response.then().statusCode(statusCode);
    }

    // Scenario 1: PATCH request should update a specific field
    @Then("the response should contain {string} in the {string} field")
    public void the_response_should_contain_in_the_field(String expectedValue, String field) 
    {
        response.then().assertThat().body(field, equalTo(expectedValue)); 
        System.out.println("Updated Response Payload: " + response.getBody().asString()); 
    }
    
    // Scenario 2: PATCH request should return a confirmation message    
    @Then("the response should contain an error message")
    public void the_response_should_contain_an_error_message() 
    {
        response.then().assertThat().body("error", notNullValue()); 
        System.out.println("Error Response: " + response.getBody().asString()); 
    }

    
    // Scenario 3: Invalid PATCH request should return an error message
    @Then("the response should contain {string} in the response message")
    public void the_response_should_contain_in_the_response_message(String string) 
    {
    	response.then().assertThat().body("error", notNullValue()); 
    }
    
}