package stepdef;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import Utilities.configReader;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class getRequests 
{
    private RequestSpecification request;
    private Response response;
    private configReader config = new configReader(); // Initialize configReader

    // Common setup for all scenarios: Define API endpoint dynamically (unique step name)
    @Given("the GET API endpoint {string}")
    public void the_get_api_endpoint(String dynamicId) 
    {
        String baseUrl = config.getProperty("baseUrl"); // Get base URL from config
        RestAssured.useRelaxedHTTPSValidation(); // Ignore SSL validation
        request = given().baseUri(baseUrl + dynamicId); // Initialize request
    }

    // Send GET request
    @When("I send a GET request")
    public void i_send_a_get_request() 
    {
        response = request.header("Content-Type", "application/json") // Add Content-Type
                         .get();
    }
    
    // Common validation step: Check response status code (unique step name)
    @Then("GET response status code should be {int}")
    public void get_response_status_code_should_be(Integer statusCode) 
    {
        response.then().statusCode(statusCode);
        System.out.println("Response Status Code: " + response.getStatusCode()); // Log status code
    }

    // Verify response contains a list of records
    @Then("GET response should contain a list of records")
    public void get_response_should_contain_a_list_of_records() 
    {
        response.then().assertThat().body("$", hasSize(greaterThan(0))); 
        System.out.println("Number of records retrieved: " + response.jsonPath().getList("$").size());
        System.out.println("Response Payload: " + response.getBody().asString()); 
    }
 // Replace the step with this one
    @Then("GET response should contain an error message")
    public void get_response_should_contain_an_error_message() {
        response.then().assertThat().body("error", notNullValue());
        System.out.println("Error Response: " + response.getBody().asString()); 
    }

    // Verify specific value exists in the records array (works for both single and multiple records)
    @Then("GET response should contain {string} in the records")
    public void get_response_should_contain_in_the_records(String expectedValue) {
        response.then().assertThat().body("name", hasItem(expectedValue));
        System.out.println("Found expected value in records: " + expectedValue);
    }
}
