package stepdef;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import Utilities.configReader; 
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class putRequests {
    private RequestSpecification request;
    private Response response;
    private configReader config = new configReader(); 

    // Common setup for all scenarios: Define API endpoint dynamically    
    @Given("the API endpoint {string}")
    public void the_api_endpoint(String dynamicId) 
    {
        String baseUrl = config.getProperty("baseUrl"); 
        RestAssured.useRelaxedHTTPSValidation(); // Ignore SSL validation
        request = given().baseUri(baseUrl + dynamicId); 
    }

    // Scenario 1: Send PUT request with payload  
    @When("I send a PUT request with the following payload:")
    public void i_send_a_put_request_with_the_following_payload(String payload) 
    {
        response = request.header("Content-Type", "application/json") 
                         .body(payload)
                         .put();
    }

    // Common validation step: Check response status code 
    @Then("response status code should be {int}")
    public void response_status_code_should_be(Integer statusCode) 
    {
        response.then().statusCode(statusCode);
        System.out.println("Response Status Code: " + response.getStatusCode()); 
    }

    // Scenario 1: Verify successful record update  
    @Then("response should contain {string} in {string} field")
    public void response_should_contain_in_the_field(String expectedValue, String field) 
    {
        response.then().assertThat().body(field, equalTo(expectedValue)); 
        System.out.println("Updated Response Payload: " + response.getBody().asString()); 
    }
    

    // Scenario 2: Verify API does not update a record at an invalid endpoint  
    @Then("response should contain an error message")
    public void response_should_contain_an_error_message() {
        response.then().assertThat().body("error", notNullValue()); 
        System.out.println("Error Response: " + response.getBody().asString()); 
    }

    // Scenario 3: Send PUT request with an empty payload  
    @When("I send a PUT request with an empty payload")
    public void i_send_a_put_request_with_an_empty_payload() {
        response = request.header("Content-Type", "application/json") 
                         .body("") // Empty payload
                         .put();

        System.out.println("Response Body: " + response.getBody().asString());
        
    }

    // Scenario 3 & 4: Validate failure messages ("Bad Request" or "Not Found")      
    @Then("response should contain {string} in the response message")
    public void response_should_contain_in_the_response_message(String message) {
        
        System.out.println("Response Body: " + response.getBody().asString());

        response.then().assertThat()
            .body("message", anyOf(equalTo(message), isEmptyOrNullString()));
    }

}