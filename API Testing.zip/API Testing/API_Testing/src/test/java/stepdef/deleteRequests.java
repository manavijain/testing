package stepdef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.cucumber.datatable.DataTable;
import org.junit.Assert;

import Utilities.configReader;

import static io.restassured.RestAssured.given;

import java.util.List;
import java.util.Map;

public class deleteRequests {
    
    private RequestSpecification request;
    private Response response;
    private String apiEndpoint;
    private configReader config = new configReader();

    // Set API endpoint
    @Given("API  endpoint {string}")
    public void api__endpoint(String dynamicId) 
    {   
        String baseUrl = config.getProperty("baseUrl"); 
        RestAssured.useRelaxedHTTPSValidation(); // Ignore SSL validation
        request = given().baseUri(baseUrl + dynamicId); 
    }

    // Send DELETE request without payload
    @When("I send a DELETE request")
    public void i_send_a_delete_request() 
    {
    	response = request.when().delete();

        System.out.println("Response Status Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());
    }

    // Validate response status code
    @Then("the api response status code should be {int}")
    public void the_api_response_status_code_should_be(Integer expectedStatusCode) 
    {
        Assert.assertEquals("Unexpected status code!", expectedStatusCode.intValue(), response.getStatusCode());
    }

    // Validate deletion success scenario
    @Then("the record should be removed from the system")
    public void the_record_should_be_removed_from_the_system() 
    {
    	Assert.assertTrue(response.getBody().asString().contains("has been deleted."));
    }

    // Validate failure scenario (Invalid ID)
    @Then("the response should contain error message")
    public void the_response_should_contain_error_message() 
    {
        //Assert.assertTrue(response.getBody().asString().contains("Not Found") || response.getBody().asString().contains("Invalid ID"));
    	Assert.assertTrue(response.getBody().asString().contains("doesn't exist."));
    }

    // Send DELETE request with a payload
    @When("I send a DELETE request with the following payload")
    public void i_send_a_delete_request_with_the_following_payload(DataTable dataTable) 
    {
	    List<Map<String, String>> payloadList = dataTable.asMaps(String.class, String.class);

	    response = request.header("Content-Type", "application/json")
	                      .body(payloadList)
	                      .delete();

	    System.out.println("Response Status: " + response.getStatusCode());
	    System.out.println("Response Body: " + response.getBody().asString());
    }
}

