package stepdef;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import Utilities.configReader;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class postRequests 
{
    private RequestSpecification request;
    private Response response;
    private String requestBody;
    private configReader config = new configReader();

    // Setup POST API endpoint
    @Given("the POST API endpoint {string}")
    public void the_post_api_endpoint(String endpoint) 
    {
        String baseUrl = config.getProperty("baseUrl");
        RestAssured.useRelaxedHTTPSValidation();
        request = given().baseUri(baseUrl + endpoint);
    }

    // Valid payload
    @Given("I have a valid POST request payload:")
    public void i_have_a_valid_post_request_payload(String payload)
    {
        this.requestBody = payload;
    }

    // Duplicate payload
    @Given("I have a duplicate POST request payload:")
    public void i_have_a_duplicate_post_request_payload(String payload) 
    {
        this.requestBody = payload;
    }

    // No payload
    @Given("I have no request payload")
    public void i_have_no_request_payload() 
    {
        this.requestBody = null;
    }

    // Invalid field names payload
    @Given("I have an invalid field names payload:")
    public void i_have_an_invalid_field_names_payload(String payload)
    {
        this.requestBody = payload;
    }

    // Invalid datatype payload
    @Given("I have an invalid datatype payload:")
    public void i_have_an_invalid_datatype_payload(String payload) 
    {
        this.requestBody = payload;
    }

    // Empty string payload
    @Given("I have an empty string payload:")
    public void i_have_an_empty_string_payload(String payload)
    {
        this.requestBody = payload;
    }

    // Send POST request
    @When("I send a POST request")
    public void i_send_a_post_request() {
        if (requestBody != null) {
            response = request.header("Content-Type", "application/json")
                             .body(requestBody)
                             .post();
        } else {
            response = request.header("Content-Type", "application/json")
                             .post();
        }
        System.out.println("Request Body: " + requestBody);
        System.out.println("Response Status: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());
    }

    // Validate POST response status code - STRICT VALIDATION (will fail for bugs)
    @Then("POST response status code should be {int}")
    public void post_response_status_code_should_be(Integer expectedStatusCode)
    {
        int actualStatusCode = response.getStatusCode();
        System.out.println("Expected Status Code: " + expectedStatusCode);
        System.out.println("Actual Status Code: " + actualStatusCode);
        
        // STRICT validation - this will FAIL when API doesn't behave as expected
        response.then().statusCode(expectedStatusCode);
    }

    // Validate specific field value
    @Then("POST response should contain {string} in {string} field")
    public void post_response_should_contain_in_field(String expectedValue, String fieldName) 
    {
        response.then().assertThat().body(fieldName, equalTo(expectedValue));
        System.out.println("Validated field '" + fieldName + "' contains: " + expectedValue);
    }

    // Validate new ID is generated
    @Then("POST response should contain a new generated {string}")
    public void post_response_should_contain_a_new_generated_field(String fieldName) 
    {
        response.then().assertThat().body(fieldName, notNullValue());
        response.then().assertThat().body(fieldName, not(emptyString()));
        String generatedId = response.jsonPath().getString(fieldName);
        System.out.println("Generated " + fieldName + ": " + generatedId);
    }

    // Validate createdAt timestamp
    @Then("POST response should contain {string} timestamp")
    public void post_response_should_contain_timestamp(String fieldName) 
    {
        response.then().assertThat().body(fieldName, notNullValue());
        String timestamp = response.jsonPath().getString(fieldName);
        System.out.println("Created timestamp: " + timestamp);
    }

    // Validate specific error message for 400 Bad Request - STRICT VALIDATION
    @Then("POST response should contain {string} error message")
    public void post_response_should_contain_specific_error_message(String expectedError)
    {
        // This will FAIL if API doesn't return proper error response
        response.then().assertThat().body("error", containsString(expectedError));
        System.out.println("Error message validated: " + response.jsonPath().getString("error"));
    }

    // Generic error message validation - STRICT VALIDATION
    @Then("POST response should contain error message")
    public void post_response_should_contain_error_message() 
    {
        // This will FAIL if API doesn't return error field
        response.then().assertThat().body("error", notNullValue());
        System.out.println("Error message: " + response.jsonPath().getString("error"));
    }
}
