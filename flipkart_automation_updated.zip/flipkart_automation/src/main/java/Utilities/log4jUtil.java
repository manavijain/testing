package Utilities;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.text.SimpleDateFormat;
import java.util.Date;

public class log4jUtil  
{
    public static final Logger logger = Logger.getLogger(log4jUtil.class);

    static  
    {
        PropertyConfigurator.configure("src/test/resource/log4j.properties");
    }

    public static void info(String message)  
    {
        logger.info(message);
    }

    public static void error(String message, Exception e)  
    {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        if (e != null)  
        {
            StackTraceElement relevantElement = null;

            // Iterate through stack trace to find a class from your project
            for (StackTraceElement element : e.getStackTrace())  
            {
                if (element.getClassName().startsWith("stepdef") || element.getClassName().startsWith("Utilities"))  
                {
                    relevantElement = element;
                    break;  // Stop when first relevant project class is found
                }
            }

            if (relevantElement != null)  
            {
                logger.error("[" + timestamp + "] ERROR: " + message);
                logger.error("Occurred at: " + relevantElement.getClassName() + "." + relevantElement.getMethodName() +
                             " (" + relevantElement.getFileName() + ":" + relevantElement.getLineNumber() + ")");
                logger.error("Exception Message: " + e.getMessage());
            }  
            else  
            {
                logger.error("[" + timestamp + "] ERROR: " + message);
                logger.error("Could not determine project class. Exception Message: " + e.getMessage());
            }
        }  
        else  
        {
            logger.error("[" + timestamp + "] ERROR: " + message);
        }
    }
}