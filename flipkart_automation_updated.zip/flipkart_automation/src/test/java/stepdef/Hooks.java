//package stepdef;
//
//import io.cucumber.java.After;
//import io.cucumber.java.Scenario;
//import Utilities.baseclass;
//import Utilities.screenshot;
//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;
//import org.openqa.selenium.WebElement;
//
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//public class Hooks extends baseclass 
//{
//    private static final Logger logger = Logger.getLogger(Hooks.class);
//  
//    static  
//    {
//        PropertyConfigurator.configure("src/test/resources/log4j.properties");
//    }
//
//    private static Exception lastException = null;
//    private static WebElement lastFailedElement = null;  // Track the last failing element
//
//    public static void setLastException(Throwable t) 
//    {
//        lastException = (Exception) t;
//    }
//
//    public static void setLastFailedElement(WebElement element) 
//    {
//        lastFailedElement = element;  // Set the failing element for highlighting
//    }
//
//    @After
//    public void tearDown(Scenario scenario) 
//    {
//        if (scenario.isFailed()) 
//        {
//            System.err.println(" Scenario FAILED: " + scenario.getName());
//
//            // Take screenshot with element highlighting
//            screenshot.captureScreenshot(dr, scenario.getName(), lastFailedElement);
//
//            // Log error with stack trace
//            error(scenario.getName(), lastException);
//        }
//    }
//
//    public static void error(String message, Exception e)  
//    {
//        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
//
//        if (e != null)  
//        {
//            StackTraceElement relevantElement = null;
//
//            // Iterate through stack trace to find a class from your project
//            for (StackTraceElement element : e.getStackTrace())  
//            {
//                if (element.getClassName().startsWith("stepdef") || element.getClassName().startsWith("Utilities"))  
//                {
//                    relevantElement = element;
//                    break;  // Stop when first relevant project class is found
//                }
//            }
//
//            if (relevantElement != null)  
//            {
//                logger.error("[" + timestamp + "] ERROR: " + message);
//                logger.error("Occurred at: " + relevantElement.getClassName() + "." + relevantElement.getMethodName() +
//                             " (" + relevantElement.getFileName() + ":" + relevantElement.getLineNumber() + ")");
//                logger.error("Exception Message: " + e.getMessage());
//            }  
//            else  
//            {
//                logger.error("[" + timestamp + "] ERROR: " + message);
//                logger.error("Could not determine project class. Exception Message: " + e.getMessage());
//            }
//        }  
//        else  
//        {
//            logger.error("[" + timestamp + "] ERROR: " + message);
//        }
//    }
//}


package stepdef;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import Utilities.baseclass;
import Utilities.screenshot;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebElement;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Hooks extends baseclass 
{
    private static final Logger logger = Logger.getLogger(Hooks.class);
  
    static  
    {
        PropertyConfigurator.configure("src/test/resources/log4j.properties");
    }

    private static Exception lastException = null;
    private static WebElement lastFailedElement = null;  // Track the last failing element

    public static void setLastException(Throwable t) 
    {
        lastException = (Exception) t;
    }

    public static void setLastFailedElement(WebElement element) 
    {
        lastFailedElement = element;  // Set the failing element for highlighting
    }

    @After
    public void tearDown(Scenario scenario) 
    {
        if (scenario.isFailed()) 
        {
            System.err.println(" Scenario FAILED: " + scenario.getName());

            // Take screenshot with element highlighting
            screenshot.captureScreenshot(dr, scenario.getName(), lastFailedElement);

            // Log error with stack trace
            error(scenario.getName(), lastException);
        }
    }

    public static void error(String message, Exception e)  
    {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        if (e != null)  
        {
            StackTraceElement relevantElement = null;

            // Iterate through stack trace to find a class from your project
            for (StackTraceElement element : e.getStackTrace())  
            {
                if (element.getClassName().startsWith("stepdef") || element.getClassName().startsWith("Utilities"))  
                {
                    relevantElement = element;
                    break;  // Stop when first relevant project class is found
                }
            }

            if (relevantElement != null)  
            {
                logger.error("[" + timestamp + "] ERROR: " + message);
                logger.error("Occurred at: " + relevantElement.getClassName() + "." + relevantElement.getMethodName() +
                             " (" + relevantElement.getFileName() + ":" + relevantElement.getLineNumber() + ")");

                // Log only the relevant exception message without unnecessary WebDriver details
                String[] exceptionLines = e.getMessage().split("\n");  
                logger.error("Exception Message: " + exceptionLines[0]); // Logs only the first line of exception  
            }  
            else  
            {  
                logger.error("[" + timestamp + "] ERROR: " + message);
                logger.error("Exception Message: " + e.getMessage().split("\n")[0]);  
            }  
        }  
        else  
        {  
            logger.error("[" + timestamp + "] ERROR: " + message);
        }  
    }
}