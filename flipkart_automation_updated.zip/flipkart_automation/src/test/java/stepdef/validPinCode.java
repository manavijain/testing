//package stepdef;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.WebElement;
//import Utilities.baseclass;
//import Utilities.configReader;
//import io.cucumber.java.en.Then;
//
//public class validPinCode extends baseclass {
//
//    configReader config = new configReader();
//    
//    @Then("the valid pincode is entered")
//    public void the_valid_pincode_is_entered() 
//    {
//        // Switch to new tab
//        for (String windowHandle : dr.getWindowHandles()) 
//        {
//            dr.switchTo().window(windowHandle);
//        }
//
//        // Delivery pincode element
//        WebElement pincodeElement = dr.findElement(By.xpath("//input[@class='AFOXgu']"));
//        pincodeElement.click();
//        pincodeElement.sendKeys(config.getProperty("valid_pincode"));
//
//        // Check now button
//        WebElement checknowButton = dr.findElement(By.xpath("//span[@class='i40dM4']"));
//        checknowButton.click();
//
//        try 
//        {
//            // Display delivery date
//            WebElement deliveryDate = dr.findElement(By.xpath("//div[@class='hVvnXm']//span[@class='Y8v7Fl']"));
//            String date = deliveryDate.getText();
//            System.out.println("The entered pincode is valid");
//            System.out.println("Delivery date: " + date);
//        } 
//        catch (Exception e) 
//        {
//            WebElement outOfStock = dr.findElement(By.xpath("//div[@class='nyRpc8']"));
//            String message = outOfStock.getText();
//            
//            if (message.contains("Currently out of stock in this area")) 
//            {
//                System.out.println("The entered pincode is valid but delivery is not available in this area");
//            }
//            
//            Hooks.setLastException(e);
//            throw e;
//        }
//    }
//}





package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Utilities.baseclass;
import Utilities.configReader;
import io.cucumber.java.en.Then;

public class validPinCode extends baseclass {

    configReader config = new configReader();
    
    @Then("the valid pincode is entered")
    public void the_valid_pincode_is_entered() 
    {
        try 
        {
            // Switch to new tab
            for (String windowHandle : dr.getWindowHandles()) 
            {
                dr.switchTo().window(windowHandle);
            }

            // Delivery pincode element
            WebElement pincodeElement = dr.findElement(By.xpath("//input[@class='AFOXgu']"));
            pincodeElement.click();
            pincodeElement.sendKeys(config.getProperty("valid_pincode"));

            // Check now button
            WebElement checknowButton = dr.findElement(By.xpath("//span[@class='i40dM4']"));
            checknowButton.click();

            // Display delivery date
            WebElement deliveryDate = dr.findElement(By.xpath("//div[@class='hVvnXm']//span[@class='Y8v7Fl']"));
            String date = deliveryDate.getText();
            System.out.println("The entered pincode is valid");
            System.out.println("Delivery date: " + date);
        } 
        catch (Exception e) 
        {
            Hooks.setLastException(e);
            Hooks.setLastFailedElement(dr.findElement(By.xpath("//span[@class='i40dM4']"))); // Store the failing element
            throw e;
        }        
    }
}