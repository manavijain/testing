package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Utilities.baseclass;
import Utilities.configReader;
import io.cucumber.java.en.Then;

public class invalidPinCode extends baseclass {

    configReader config = new configReader();

    @Then("the invalid pincode is entered")
    public void the_invalid_pincode_is_entered() 
    {
        try 
        {
            // Switch to new tab
            for (String windowHandle : dr.getWindowHandles()) 
            {
                dr.switchTo().window(windowHandle);
            }

            // Change button: To change the delivery pincode
            WebElement changeButton = dr.findElement(By.xpath("//span[@class='i40dM4']"));
            changeButton.click();

            // Delivery pincode element
            WebElement pincodeElement = dr.findElement(By.xpath("//input[@class='AFOXgu']"));
            pincodeElement.click();
            pincodeElement.sendKeys(config.getProperty("invalid_pincode"));

            // Check now button
            WebElement checknowButton = dr.findElement(By.xpath("//span[@class='i40dM4']"));
            checknowButton.click();

            // Display error message
            WebElement errorMessage = dr.findElement(By.xpath("//div[@class='dYhUKY']/div[1]"));
            String error = errorMessage.getText();
            System.out.println("Error Message: " + error);
        } 
        catch (Exception e) 
		{
		    Hooks.setLastException(e);
		    Hooks.setLastFailedElement(dr.findElement(By.xpath("//div[@class='dYhUKY']/div[1]"))); // Store the failing element
		    throw e;
		}
    }
}