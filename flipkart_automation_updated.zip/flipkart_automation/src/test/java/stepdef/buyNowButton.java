package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Utilities.baseclass;
import io.cucumber.java.en.Then;

public class buyNowButton extends baseclass
{
	@Then("the presence of Buy Now button is checked")
	public void the_presence_of_Buy_Now_button_is_checked() 
	{
    	try
	    {
			// Switch to new tab
	        for (String windowHandle : dr.getWindowHandles()) 
	        {
	            dr.switchTo().window(windowHandle);
	        }
	    	WebElement button1 = dr.findElement(By.xpath("//button[@class='QqFHMw vslbG+ _3Yl67G _7Pd1Fp']"));
	    	String button = button1.getText();
	    	Assert.assertEquals("BUY NOW", button);
	    	System.out.println("Buy now button is present");
	    }
    	catch (Exception e) 
		{
		    Hooks.setLastException(e);
		    Hooks.setLastFailedElement(dr.findElement(By.xpath("//button[@class='QqFHMw vslbG+ _3Yl67G _7Pd1Fp']"))); // Store the failing element
		    throw e;
		}
	}
}
