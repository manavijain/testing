package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = ("src/test/resources/Features"),
		glue=("stepdef"),
		plugin = {"pretty", "html:target/htmlreports/report.html",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
		tags = "@name"
	)

public class verifyProduct extends AbstractTestNGCucumberTests
{
	
}

