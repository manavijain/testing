package stepdef;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utilities.baseclass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
 
public class commonSteps extends baseclass
{

	@Given("The flipkart home page is displayed")
	public void the_flipkart_home_page_is_displayed() 
	{
		launch_edge();
	}
 
	@When("user navigates to {string} section")
	public void user_navigates_to_section(String string) throws InterruptedException
	{
		//To click home and furniture
        dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/div[1]/div/div[1]/div/div/div/div/div[1]/a[7]/div/div/span/span")).click();
        
        //to click kitchen and dining
        WebElement hover = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/span[6]"));
        Actions act = new Actions(dr);
        act.moveToElement(hover).perform();
        
        //to click cookware section
    	Thread.sleep(2000);
    	dr.findElement(By.xpath("//a[@class='jBYtJt cNDIdi CP4tVY'][1][@title='Kitchen, Cookware & Serveware']")).click();
    	Thread.sleep(2000);
    }
	
	@When("the user selects 6th page")
	public void the_user_selects_6th_page() throws InterruptedException 
	{
    	Thread.sleep(2000);
    	dr.findElement(By.xpath("//nav//a[6]")).click();
    }
    
    @When("the user selects 6th row and 2nd product")
	public void the_user_selects_6th_row_and_2nd_product() throws InterruptedException 
	{
    	//to select 6th row
    	Thread.sleep(2000);
    	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[7]"));
    	
    	//to select 2nd product
    	Thread.sleep(2000);
    	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[7]/div/div[2]/div/a[1]/div[1]/div/div/img")).click();
    	
	}
    
 
}
