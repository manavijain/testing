package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Utilities.baseclass;
import io.cucumber.java.en.Then;

public class verifyProductName extends baseclass
{
	@Then("the product name is fetched")
	public void the_product_name_is_fetched() 
	{
		try 
	    {
			// Switch to new tab
	        for (String windowHandle : dr.getWindowHandles()) 
	        {
	            dr.switchTo().window(windowHandle);
	        }
	        
	        // Locate the product name element
	        WebElement productNameElement = dr.findElement(By.xpath("//span[@class='VU-ZEz']"));
	        String productName = productNameElement.getText();
	        System.out.println("Fetched Product Name: " + productName);
	    } 
	    catch (Exception e) 
	    {
	        //System.err.println("Product name not found: " + e.getMessage());
	        Hooks.setLastException(e);
            throw e;
	    }

	}	
}
