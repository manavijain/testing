package stepdef;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.baseclass;
import io.cucumber.java.en.Then;

public class verifyProductPrice extends baseclass 
{
    @Then("the product price is fetched")
    public void the_product_price_is_fetched() 
    {
        WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(10));

        try 
        {
            // Switch to new tab
            for (String windowHandle : dr.getWindowHandles()) 
            {
                dr.switchTo().window(windowHandle);
            }

            // Try locating the product price
            WebElement productPriceElement = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[@class='x+7QT1']//div[@class='Nx9bqj CxhGGd']")
            ));
            System.out.println("Fetched product's price: " + productPriceElement.getText());
        } 
        catch (Exception e) 
        {
            System.out.println("Product price not found, trying EMI price...");

            // Try finding EMI price within the same catch block
            try 
            {
                WebElement emiElement = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div[3]/div[1]/div[1]/div")
                ));
                System.out.println("Fetched EMI price: " + emiElement.getText());
            } 
            catch (Exception e1) 
            {
                //System.out.println("Neither product price nor EMI price found.");
            	Hooks.setLastException(e1);
                throw e1;
            }
        }
    }
}