package Utilities;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class screenshot extends baseclass {

    public static String captureScreenshot(String scenarioName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = scenarioName.replaceAll(" ", "_") + "_" + timestamp + ".png";
        String screenshotPath = "screenshots/" + fileName;

        File srcFile = ((TakesScreenshot) dr).getScreenshotAs(OutputType.FILE);
        File destFile = new File(screenshotPath);

        try 
        {
            FileUtils.copyFile(srcFile, destFile);
            System.out.println(" Screenshot saved: " + screenshotPath);
        } 
        catch (IOException e) 
        {
            System.err.println(" Failed to save screenshot: " + e.getMessage());
        }

        return screenshotPath;
    }
}
