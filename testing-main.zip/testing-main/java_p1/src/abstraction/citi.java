package abstraction;

public class citi extends bank{
	
	int getRateOfInterest()
	{
		return 7;
	}
}
