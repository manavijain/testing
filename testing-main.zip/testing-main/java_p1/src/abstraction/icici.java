package abstraction;

public class icici extends bank{
	
	int getRateOfInterest()
	{
		return 5;
	}
}
