package strings;

public class egsubstring {

	public static void main(String[] args)
	{
		String str="Name : Surya";
		String s1=str.substring(7);
		System.out.println(s1);
	}
}
