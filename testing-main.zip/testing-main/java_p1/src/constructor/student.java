package constructor;

public class student {
	
	public int id;
	public float english,maths,avg;
	public String name;
	
	//Constructor  
	public student(String n,int i,float e,float m)
	{
		name=n;
		english=e;
		maths=m;
		id=i;
		avg=0;
	}
	
	
}
