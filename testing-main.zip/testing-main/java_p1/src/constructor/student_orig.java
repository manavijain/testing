package constructor;

public class student_orig {
	
}
