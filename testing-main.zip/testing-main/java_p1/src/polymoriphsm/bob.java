package polymoriphsm;

public class bob extends bank {
	
	float getRateOfInterest()
	{
		return 8.0f;
	}
}
