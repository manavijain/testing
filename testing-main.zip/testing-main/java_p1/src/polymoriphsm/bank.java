package polymoriphsm;

//parent class

public class bank {

	float  getRateOfInterest() {
		return 0;
	}

}
