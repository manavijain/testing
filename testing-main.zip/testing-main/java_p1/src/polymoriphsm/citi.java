package polymoriphsm;

public class citi extends bank {
	
	float getRateOfInterest()
	{
		return 8.5f;
	} 
}
