package polymoriphsm;

public class Vehicle {
	
	int speed;
	String fueltype;
	
	void start()
	{
		System.out.println("Vehicle has started");
	}
}
