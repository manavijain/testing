package polymoriphsm;

public class canara extends bank {
	
	float getRateOfInterest()
	{
		return 7.5f;
	}
}
