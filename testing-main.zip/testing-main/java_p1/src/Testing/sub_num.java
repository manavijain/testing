package Testing;

public class sub_num {
	
	public int sub(int n,int m)
	{
		System.out.println("Subtracting nums");
		return n-m;
	}
}
