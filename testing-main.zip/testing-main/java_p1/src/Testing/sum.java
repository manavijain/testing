package Testing;

public class sum {

		public int getsum(int[] input) {
			int s=0;
			for(int i : input)
			{
				s= s+i;
			}
			return s;
		}
}
