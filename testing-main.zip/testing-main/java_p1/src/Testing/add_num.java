package Testing;

public class add_num {
	
	public int sum(int n,int m)
	{
		System.out.println("Adding nums");
		return n+m;
	}
}
