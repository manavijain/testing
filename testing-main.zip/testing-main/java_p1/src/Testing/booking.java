package Testing;

public class booking {
	
	int bookingid,noofseats,totalamt;
	String routeId;
	
	booking( int bookingid,int noofseats,int totalamt,String routeId)
	{
		this.bookingid = bookingid;
		this.noofseats = noofseats;
		this.totalamt = totalamt;
		this.routeId = routeId;
	}
	
}
