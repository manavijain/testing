package Testing;

public class product {
	int id,price;
	int quantity,unitprice;
	String name,brand;
	
	product(int id,String name,int price,String brand,int quantity)
	{
		this.id=id;
		this.name=name;
		this.price=price;
		this.brand=brand;
		this.quantity=quantity;	
	}	
}
