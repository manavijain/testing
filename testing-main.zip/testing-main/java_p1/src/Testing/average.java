package Testing;

public class average {
	
	public int avg(int ai,int ds,int ml)
	{
		int avg=(ai+ds+ml)/3;
		return avg;
	}
}
