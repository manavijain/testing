package arraylist;

public class fruits {
	
	String name;
	String colour;
	
	
	fruits(String name,String colour)
	{
		this.name=name;
		this.colour=colour;	
	}
	
	void display()
	{
		System.out.println("Fruit Name: "+name);
		System.out.println("Fruit Colour: "+colour);	
	}
	
}
