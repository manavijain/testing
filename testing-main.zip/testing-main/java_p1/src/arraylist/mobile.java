package arraylist;

public class mobile {
	
	public String brand,model;
	public int price,ram;
	
	//constructor
	public mobile(String b,String m,int p,int r)
	{
		brand = b;
		model = m;
		price = p;
		ram = r;
	}	
}
