package hashmap;

public class student {
	
	int id;
	String name;
	int age;
	
public student(String n, int i, int a) {
		this.name=n;
		this.id=i;
		this.age=a;
	}

}
