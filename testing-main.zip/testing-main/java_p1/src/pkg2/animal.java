package pkg2;

//Parent class = base class 

public class animal {
	
	public void eat()
	{
		System.out.println("Dog is eating ");
	}
	
	public void sleep()
	{
		System.out.println("Dog is sleeping ");
	}
	
}
