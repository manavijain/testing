package pkg2;

//child class = subclass

public class dog extends animal{
	
	public void bark()
	{
		System.out.println("Dog is barking");
	}
}
