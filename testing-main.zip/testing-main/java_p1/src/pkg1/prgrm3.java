package pkg1;

public class prgrm3 {
	public static void main(String[] args) {
		int i=1;
		while(i<=5)
		{
			System.out.print(i+" ");
			i++;
		}
	}
}
