package pkg1;

public class prgrm2 {

	public static void main(String[] args) {
		
		for(int i=2;i<=20;i=i+3)
		{
			System.out.print(i+" ");
		}
		
	}

}
