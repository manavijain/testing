package pkg1;

import java.util.Arrays;

public class prgrm14 {

	public static void main(String[] args) {
		int numbers[]= new int[5];
		Arrays.fill(numbers, 10);
		
		for(int n:numbers)
		{
			System.out.print(n+" ");
		}

	}

}
