/*package stepdef1;

import io.cucumber.java.en.Given;

public class weblaunchsteps extends Utilities.common_methods
{

	@Given("The login page is displayed")
	public void the_login_page_is_displayed() 
	{
		launch_chrome ("https://demowebshop.tricentis.com/");
	    System.out.println("The login page is displayed");
	}
}*/
