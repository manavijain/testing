//package stepdef1;
//
//import Utilities.common_methods;
//import io.cucumber.java.After;
//import io.cucumber.java.Before;
//
//
//public class hooks extends common_methods
//{
//	@Before
//	public void setup()
//	{
//		System.out.println("before hook");
//		//weblaunchsteps w = new weblaunchsteps();
//		//w.the_login_page_is_displayed();
//		launch_chrome("https://demowebshop.tricentis.com/");
//		System.out.println("The login page is displayed");
//		
//	}
//	
//	@After
//	public void teardown()
//	{
//		System.out.println("after hook");
//		close_chrome();
//	}	
//	
//	
//}
