package utilities;

public enum ScenarioContext 
{
	USERNAME,
	SESSION_TOKEN;
}
