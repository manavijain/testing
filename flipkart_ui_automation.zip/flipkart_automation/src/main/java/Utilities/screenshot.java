package Utilities;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class screenshot extends baseclass 
{

    public static String captureScreenshot(WebDriver driver, String scenarioName, WebElement failedElement)
    {
        // Apply red border highlight to the failing element
        highlightElement(driver, failedElement);

        // Capture screenshot after highlighting
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = scenarioName.replaceAll(" ", "_") + "_" + timestamp + ".png";
        String screenshotPath = "screenshots/" + fileName;

        File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File destFile = new File(screenshotPath);

        try 
        {
            FileUtils.copyFile(srcFile, destFile);
            System.out.println(" Screenshot saved: " + screenshotPath);
        } 
        catch (IOException e) 
        {
            System.err.println(" Failed to save screenshot: " + e.getMessage());
        }

        return screenshotPath;
    }

    private static void highlightElement(WebDriver driver, WebElement element) 
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='3px solid red'", element);
    }
}