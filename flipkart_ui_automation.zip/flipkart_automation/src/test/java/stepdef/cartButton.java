package stepdef;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.baseclass;
import io.cucumber.java.en.Then;

public class cartButton extends baseclass
{
	@Then("the presence of cart button is checked")
	public void the_presence_of_cart_button_is_checked() 
	{
		try 
	    {
			// Switch to new tab
	        for (String windowHandle : dr.getWindowHandles()) 
	        {
	            dr.switchTo().window(windowHandle);
	        }
	        
	        WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(10));
	        
	        // Locate "Cart" button 
	        WebElement cartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='QqFHMw vslbG+ In9uk2']")));
	
	        if (cartButton.isDisplayed()) 
	        {
	            System.out.println("Add To Cart button is present.");
	        } 
	        else 
	        {
	            System.out.println("Add To Cart button is not visible.");
	        }
		 } 
		catch (Exception e) 
		{
		    Hooks.setLastException(e);
		    Hooks.setLastFailedElement(dr.findElement(By.xpath("//button[@class='QqFHMw vslbG+ In9uk2']"))); // Store the failing element
		    throw e;
		}
	}
}
