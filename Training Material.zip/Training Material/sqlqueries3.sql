use mydb;

load  data infile "C:\Users\mmanavi.jain\Documents\2630648 - Manavi\\std.csv" into table student;

load data local infile "C:\Users\mmanavi.jain\Documents\2630648 - Manavi\\std.csv"
into table student
fields terminated by ','
lines terminated by '\n';

use mydb;

create table students ( sid int primary key, sname varchar(20),marks int, deptId int, age int,constraint fk foreign key(deptId) references department(deptId));

create table department (deptId int,dname varchar(15),location varchar(10),primary key pk (deptId));

insert into students values(10,"Arghya",80,1,17),(11,"Bhavan",60,2,12),(12,"Chandan",75,1,19),(13,"Deepa",70,1,14),(14,"Isha",56,3,20),(15,"Gayatri",76,3,10),(16,"Harish",97,2,25),(17,"Jagan",93,3,16),(18,"Kiran",60,4,17),(19,"Lavanya",65,4,14);

insert into department values(1,"cs","mangalore"),(2,"ec","mangalore"),(3,"aiml","bangalore"),(4,"iot","udupi");

select s.sname, d.dname from students s join department d on s.deptId = d.deptId where marks = (select max(marks) from students);

select * from students where age>15;

select * from students where age>13 and marks in(60,70,80);

select sname,marks from students where marks > (select avg(marks) from students);

select upper('hello world');

select lower('HELLO WORLD');

select concat ('Hello',' ','World');

select substring('Database Training',1,8);

select substring('Database Training',9,12);

select replace('MySQL is great','great','awesome');

select round(123.56787,2);

select mod(10,3);

select abs(-20);

select current_date();

select current_time();

select now();

use mydb;

create table employee(mgrid int,empname varchar(15),salary int);

insert into employee values(100,'manavi',90000),(100,'anagha',65000),(101,'arun',40000),(102,'arjun',67000),(102,'darshan',20000);

select avg(salary) from employee;

select mgrid,avg(salary) from employee group by mgrid order by mgrid;

select mgrid,min(salary),max(salary) from employee group by mgrid;

select mgrid,min(salary),max(salary) from employee group by mgrid having max(salary)>30000;

select mgrid,min(salary),max(salary) from employee group by mgrid having max(salary)>30000 and min(salary)>10000;

select max(salary),count(*) from employee group by mgrid having max(salary)>35000;

create table std1(sid int,sname varchar(15),mgrid int,salary int,joining_date date);

desc std1;

insert into std1 values(101,'John',10,1000,'2023-03-22'),(102,'Alice',40,10000,'2023-03-22'),(103,'Robert',20,20000,'2024-05-11'),(104,'Sophia',100,20000,'2024-11-19'),(120,'Vijay',100,30000,'2024-11-19'),(201,'Appu',10,40000,'2024-07-02'),(202,'Satvika',10,50000,'2024-08-05');

select * from std1;

select lower(sname) from std1;

select upper(sname) from std1;

select substring(sname,1,3) from std1;

select length(sname) from std1;

select round(salary) from std1;

select abs(max(salary) - min(salary)) from std1;

select avg(salary),sum(salary),max(salary),min(salary) from std1;

select count(*) from std1 where joining_date > '2024-01-01';

alter table std1
add dept_id int;

update std1 set dept_id = 50 where sid in (101, 102,201);
update std1 set dept_id = 60 where sid = 103;
update std1 set dept_id = 70 where sid  in(104,120,202);

select dept_id,count(sname) from std1 group by dept_id;

select dept_id,sum(salary),avg(salary) from std1 group by dept_id;

select dept_id from std1 group by dept_id having avg(salary)>18000 ;

select dept_id from std1 group by dept_id having count(sname)>2;

select * from std1 where dept_id in(select dept_id from std1 where salary>30000);

select * from std1 where dept_id in (select dept_id from std1 where sname='Alice');

select e1.sname,e1.salary,e1.dept_id from std1 e1 where e1.salary> (select avg(e2.salary) from std1 e2 where e1.dept_id=e2.dept_id);

select e1.sname,e1.salary,e1.dept_id from std1 e1 where e1.dept_id in(select dept_id from std1 where salary =(select max(salary) from std1 group by dept_id));

select e1.sname, e1.salary, e1.dept_id from std1 e1 where e1.salary = (select max(salary) from std1 e2 where e1.dept_id = e2.dept_id);











