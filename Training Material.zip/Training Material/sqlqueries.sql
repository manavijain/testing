show databases;
create database mydb;
show databases;
use mydb;
create table dept
(
	deptId int,
    dnmae varchar(10)
    );
    show tables;
    desc dept;
    
    create table student(
    sid int,
    sname varchar(10),
    marks int,
    deptId int
    );
    
    insert into dept values(10,"cs"),(20,"aids"),(30,"csbs"),(40,"ece"),(50,"ds"),(60,"csec"),(70,"mca"),(80,"csd");
    
    select * from dept;
    
    INSERT INTO student (sid, sname, marks, deptId) VALUES
(1, 'Arun', 85, 10),
(2, 'Bala', 90, 10),
(3, 'Chitra', 78, 20),
(4, 'Divya', 82, 20),
(5, 'Eshwar', 88, 30),
(6, 'Fathima', 91, 30),
(7, 'Ganesh', 75, 40),
(8, 'Hari', 89, 40),
(9, 'Isha', 80, 50),
(10, 'Jaya', 84, 50),
(11, 'Kiran', 92, 60),
(12, 'Latha', 86, 60),
(13, 'Manoj', 77, 70),
(14, 'Nisha', 85, 70),
(15, 'Om', 79, 80),
(16, 'Pooja', 88, 80);

select * from student;

insert into student(sid,sname) values(17,"Thrisha");
select * from student;

create table s4 (sid int,sname varchar(10) not null,marks int);
show tables;

insert into s4(sid,marks) values(18,90);

create table s3 (sid int,sname varchar(10) not null default"name",marks int);

insert into s3(sid,marks) values (19,78);
select * from s3;

select * from dept;
select * from student;

insert into student values(18,"Rajesh",30,100);
select * from student;

create table d1 
(
	deptid int,
    dname varchar(10),
    constraint pk1 primary key (deptId)
);

insert into d1 values(10,"cs"),(20,"ec");
select * from d1;

create table s1 (
	sid int,
    sname varchar(10),
    marks int,
    deptId int,
    constraint fk1 foreign key(deptId) references d1(deptId));
	
    insert into s1 values(1,"shubha",75,20),(2,"arghya",98,10);
    select * from s1;
    insert into s1 values(3,"vijesh",77,100);
    select * from s1;
    
    create table employee (
		empid int,
        empname varchar(10),
        employeephone bigint);
	
    desc employee;
    
    insert into employee values(101,"Raksha",1234567890),(102,"Sahana",7036781220),(103,"Vijendra",8088727154),(104,"Manavi",1234567890);
    select * from employee;
    
    alter table employee
    add constraint unique(employeephone);
    select * from employee;
    
    delete from employee where empid=104;
    select * from employee;
    insert into employee values(104,"Manavi",7996254482);
    select * from employee;
    insert into employee values(105,"Shreya",1234567890);
    delete from employee where empid=105;
    
    alter table employee
    add constraint unique(employeephone);
    insert into employee values(105,"Shreya",1234567890);
    
    alter table employee change column employeephone empphone char(16);
    desc employee;
    select * from employee;
    rename table employee to emp;
    show tables;
    
    alter table emp 
    add usn int;
    desc emp;
    
    alter table emp
    drop usn;
    
    desc emp;
    
    show tables;
    select * from dept;
    select * from student;
    
    select * from student where marks=80;
    select * from student where marks>=68;
    select * from student where marks>=70 and deptId=10;
    select * from student where marks<=60 or marks>=80;
    select * from student where marks between 50 and 100;
    select * from student where marks in(60,88,90);
	select * from student where deptId not in(10,30);
    
    select sname from student where deptId = (select deptId from dept where dnmae ="ece");
    
    select sname from student where marks = (select max(marks) from student );
    
    select sname from student where marks = (select min(marks) from student );
    
    select count(*) from student;
    select sum(marks) from student;
    select avg(marks) from student;
    select max(marks) from student;
    select min(marks) from student;
    
    
    
