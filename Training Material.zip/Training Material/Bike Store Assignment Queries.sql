use production;
select * from production.brands;

select * from production.products where list_price>1000;

use sales;
select * from sales.customers where city='New York';

select first_name,last_name,email from customers;

select * from orders where year(order_date)=2016;

select * from products where category_id = (select category_id from categories where category_name='Mountain Bikes');

select category_id,count(product_id) from products group by category_id;

select * from products where list_price = (select max(list_price) from products);

select o.*,c.first_name,c.last_name  from orders o,customers c where o.customer_id = c.customer_id;

select * from products where model_year=2017; 

select avg(list_price) as avg from products;

select product_id,sum(quantity) from order_items group by product_id;

select s.store_id,s.store_name,sum(o.quantity * o.list_price * (1 - o.discount)) from stores s join orders ord on s.store_id=ord.store_id join order_items o on ord.order_id=o.order_id group by store_id;

select first_name,count(order_id) from customers c,orders o where c.customer_id = o.customer_id group by c.customer_id;

select sum(quantity*list_price*discount) as tot_discount from order_items;

select c.category_id,avg(p.list_price) from products p,categories c where p.category_id=c.category_id group by category_id;

select month(order_date),count(order_id) as month from orders where year(order_date)=2016 group by month(order_date);

select sum(s.quantity*p.list_price) as tot_revenue from stocks s join products p on s.product_id = p.product_id join categories c on c.category_id=p.category_id;

select state,count(customer_id) from customers group by state;

select year(o.order_date),count(oi.order_id) from orders o,order_items oi where o.order_id=oi.order_id group by year(o.order_date);

select * from orders o join order_items oi on o.order_id=oi.order_id;

select * from customers c join orders o on c.customer_id=o.customer_id;

select p.product_id,p.product_name from stocks s join products p  on p.product_id=s.product_id;

select * from orders o join stores s on o.store_id=s.store_id join staffs st on s.store_id=st.store_id;

select * from products p join categories c on p.category_id=p.category_id join brands b on p.brand_id=b.brand_id;

select c.*,count(order_id) from customers c join orders o on c.customer_id=o.customer_id group by c.customer_id having count(o.order_id)>5;

select o.* from orders o join customers c on o.customer_id=c.customer_id where c.state='CA';

select oi.product_id,sum(oi.quantity) as tot_quantity from order_items oi join orders o on oi.order_id=o.order_id group by oi.product_id; /* wrong query*/

select c.category_name,o.* from sales.orders o join order_items oi on o.order_id=oi.order_id join production.products p on oi.product_id=p.product_id join production.categories c on c.category_id=p.category_id where c.category_name = 'Electric Bikes';

select o.*,sum(oi.quantity*oi.list_price*oi.discount) as tot_discounts from orders o join order_items oi on o.order_id=oi.order_id group by o.order_id;












