create database stddata;
use stddata;
create table Student(sid int,sname varchar(20),phy int,chem int,average float);
desc Student;
select * from Student;

delete from Student;
