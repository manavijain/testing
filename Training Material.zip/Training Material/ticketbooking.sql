use mydb;
create table busroute ( routeId varchar(10) primary key, src varchar(15), dest varchar(15), totseats int, remseats int, cost int ); 

create table booking ( bookingId int  primary key, routeId varchar(10), noofseats int, totalamt int,constraint fk_route foreign key(routeId) references busroute(routeId) ) ; 

show tables;
desc busroute;
desc booking;

insert into busroute (routeId, src, dest, totseats, remseats, cost) values ('r001','moodbidri','bangalore',35,35,900),('r002','bangalore','chennai',20,20,1000),('r003','bangalore','hyderabad',15,15,650),('r004','moodbidri','chennai',25,25,800);

select * from busroute;

select * from booking;

drop table booking;