show databases;

use mydb;
show tables;
select * from student;
select * from dept;

select sid,sname from student,dept;

select sid,sname,marks,d1.deptId from student s,d1 where s.deptId=d1.deptId;

select sid,sname,marks,d1.deptId from student s join d1 on s.deptId = d1.deptId;

insert into student values(110,"Raju",87,40),(120,"Sita",67,50);
select * from student;

select * from student s join d1 on s.deptId = d1.deptId;

select * from student s left join d1 on s.deptId = d1.deptId;	/* left outer join*/

select * from student s right join d1 on s.deptId = d1.deptId;	/* right outer join*/

alter table student
add column managerId int;
select * from student;

update student set managerId=40 where sid=110;
update student set managerId=40 where sid in(110,16);

