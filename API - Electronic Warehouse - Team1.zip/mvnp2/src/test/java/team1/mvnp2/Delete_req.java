package team1.mvnp2;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Delete_req extends Http_client_library {

	Http_client_library common_methods;

    @BeforeClass
    public void setup() {
    	common_methods = new Http_client_library(); // Initializing the Commonmethods object before tests
    }

    @Test
    public void delete_with_valid_ID() {
        try {
            // Test case for deleting an object with a valid ID
            int statusCode = common_methods.getStatusCode(common_methods.deleteObject("https://api.restful-api.dev/objects/ff808181932badb60196610a32944624"));
            Assert.assertEquals(statusCode, 200, "Use a proper ID");
        } catch (IOException e) {
            // Exception handling in case of an I/O error
            System.err.println("IOException occurred while deleting with valid ID: " + e.getMessage());
            Assert.fail("Test failed due to an IOException");
        } catch (Exception e) {
            // Catching unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to an unexpected error");
        }
    }

    @Test
    public void delete_with_Invalid_id() {
        try {
            // Test case for deleting an object with an invalid ID
            int statusCode = common_methods.getStatusCode(common_methods.deleteObject("https://api.restful-api.dev/objects/ff808181932badb601"));
            Assert.assertEquals(statusCode, 404, "Invalid ID");
        } catch (IOException e) {
            // Exception handling in case of an I/O error
            System.err.println("IOException occurred while deleting with invalid ID: " + e.getMessage());
            Assert.fail("Test failed due to an IOException");
        } catch (Exception e) {
            // Catching unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to an unexpected error");
        }
    }
}
