package team1.mvnp2;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Put_req {
    String url = "https://api.restful-api.dev/objects/ff808181932badb601963a697d197e38";
    String data = "";
    Http_client_library common_methods;

    @BeforeClass
    public void setUp() {
        // Initialize the http_client_library instance before all tests
        common_methods = new Http_client_library();
    }

    @BeforeMethod
    public void beforeMethod() {
        // Re-initialize the http_client_library instance before each test
        common_methods = new Http_client_library();
    }

    @AfterMethod
    public void afterMethod() {
        try {
            // Close the HTTP client resources after each test
            if (common_methods != null) {
                common_methods.closeClient();
            }
        } catch (IOException e) {
            // Handle IOException during resource cleanup
            System.err.println("Error while closing HTTP client: " + e.getMessage());
        }
    }

    @Test
    public void PutWithValidPayload() {
        try {
            // Define the valid payload for the PUT request
            data = "{\n"
                    + "   \"name\": \"Apple MacBook Pro 105 updated\",\n"
                    + "   \"data\": {\n"
                    + "      \"year\": 2019,\n"
                    + "      \"price\": 2049.99,\n"
                    + "      \"CPU model\": \"Intel Core i9\",\n"
                    + "      \"Hard disk size\": \"1 TB\",\n"
                    + "      \"color\": \"silver\"\n"
                    + "   }\n"
                    + "}";
            // Make the PUT request and assert the status code
            int statusCode = common_methods.getStatusCode(common_methods.updateObject(url, data));
            Assert.assertEquals(statusCode, 200, "PUT request failed with valid payload.");
        } catch (IOException e) {
            // Handle IOException during API call
            System.err.println("IOException occurred in PutWithValidPayload: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Handle unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }

    @Test
    public void PutWithValidPayloadAndInvalidEndpoint() {
        try {
            // Define the payload and invalid endpoint
            String invalidUrl = "https://api.restful-api.dev/objects/ff808181932badb601";
            data = "{\n"
                    + "    \"name\": \"Google MacBook Pro 16\",\n"
                    + "    \"data\": {\n"
                    + "        \"year\": 2019,\n"
                    + "        \"price\": 1849.99,\n"
                    + "        \"CPU model\": \"Intel Core i9\",\n"
                    + "        \"Hard disk size\": \"1 TB\"\n"
                    + "    }\n"
                    + "}";
            // Make the PUT request and assert the status code
            int statusCode = common_methods.getStatusCode(common_methods.updateObject(invalidUrl, data));
            Assert.assertEquals(statusCode, 404, "Expected 404 for invalid endpoint.");
        } catch (IOException e) {
            // Handle IOException during API call
            System.err.println("IOException occurred in PutWithValidPayloadAndInvalidEndpoint: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Handle unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }

    @Test
    public void PutWithImproperPayloadAndValidEndpoint() {
        try {
            // Define the improper payload
            data = "{\n"
                    + "    \"data\": {\n"
                    + "        \"year\": 2019,\n"
                    + "        \"price\": 1849.99,\n"
                    + "        \"CPU model\": \"Intel Core i9\",\n"
                    + "        \"Hard disk size\": \"1 TB\"\n"
                    + "    }\n"
                    + "}";
            // Make the PUT request and assert the status code
            int statusCode = common_methods.getStatusCode(common_methods.updateObject(url, data));
            Assert.assertEquals(statusCode, 400, "Expected 400 for improper payload.");
        } catch (IOException e) {
            // Handle IOException during API call
            System.err.println("IOException occurred in PutWithImproperPayloadAndValidEndpoint: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Handle unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }
}
