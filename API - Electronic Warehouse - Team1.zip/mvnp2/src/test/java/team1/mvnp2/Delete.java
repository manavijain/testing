package team1.mvnp2;

import org.apache.http.HttpResponse;

public class Delete {
    public static void main(String[] args) {
        try {
        	Http_client_library commonMethods = new Http_client_library();
            String deleteUrl = "https://api.restful-api.dev/objects/ff808181932badb601963e02cd9d0"; 

            
            System.out.println("Executing DELETE operation...");
            HttpResponse response = commonMethods.deleteObject(deleteUrl);

            int statusCode = commonMethods.getStatusCode(response);
            if (statusCode == 200 || statusCode == 204) {
                System.out.println("Delete operation successful. Status Code: " + statusCode);
            } else {
                System.out.println("Delete operation failed. Status Code: " + statusCode);
            }

        } catch (Exception e) {
            System.err.println("An error occurred during the DELETE operation:");
            e.printStackTrace();
        }
    }
//    public void testInvalidEndpoint() {
//        try {
//            
//            String invalidDeleteUrl = "https://api.restful-api.dev/objects/1234";
//
//            Commonmethods commonMethods = new Commonmethods();
//            System.out.println("Testing DELETE operation on an invalid endpoint...");
//            HttpResponse response = commonMethods.deleteObject(invalidDeleteUrl);
//
//            int statusCode = commonMethods.getStatusCode(response);
//            if (statusCode == 404) {
//                System.out.println("Test passed: Status Code is 404 (Not Found)");
//            } else {
//                System.out.println("Test failed: Expected 404, but got Status Code: " + statusCode);
//            }
//
//        } catch (Exception e) {
//            System.err.println("An error occurred during the invalid endpoint test:");
//            e.printStackTrace();
//        }
//    }

}
