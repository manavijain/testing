package team1.mvnp2;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class JSONdelete {

    @Test
    public void testDeleteOperation() {
        try {
        	Http_client_library commonMethods = new Http_client_library();
            String id = "ff808181932badb601963e63ac87075c"; // Replace '123' with the ID of the object you want to delete
            String deleteUrl = String.format("https://api.restful-api.dev/objects/%s", id);

            // Perform DELETE operation
            System.out.println("Executing DELETE operation...");
            HttpResponse response = commonMethods.deleteObject(deleteUrl);

            // Verify the response status code
            int statusCode = commonMethods.getStatusCode(response);
            System.out.println("Status Code: " + statusCode);
            Assert.assertTrue(statusCode == 200 || statusCode == 204, "Expected Status Code 200 or 204, but got: " + statusCode);

            // Verify the response Content-Type header
            String contentType = response.getEntity().getContentType().getValue();
            System.out.println("Content-Type: " + contentType);
            Assert.assertTrue(contentType.contains("application/json"), "Expected Content-Type to be application/json, but got: " + contentType);

            // Verify the response body is valid JSON
            String responseBody = EntityUtils.toString(response.getEntity());
            System.out.println("Response Body: " + responseBody);
            try {
                new org.json.JSONObject(responseBody); // Parse as JSON object
                System.out.println("The response body is valid JSON.");
            } catch (Exception e) {
                System.out.println("The response body is NOT valid JSON.");
                Assert.fail("Response body is not valid JSON.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Test failed due to exception: " + e.getMessage());
        }
    }
}
