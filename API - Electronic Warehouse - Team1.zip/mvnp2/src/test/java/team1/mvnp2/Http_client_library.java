package team1.mvnp2;

import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.Assert;

public class Http_client_library {

    private final CloseableHttpClient client;

    // Default constructor to initialize the HTTP client
    public Http_client_library() {
        this.client = HttpClients.createDefault();
    }

    // General method to execute HTTP requests
    private CloseableHttpResponse executeRequest(HttpRequestBase request) throws IOException {
        CloseableHttpResponse response = client.execute(request);
        if (!isJsonResponse(response)) {
            throw new IOException("Unexpected content type: " + response.getEntity().getContentType().getValue());
        }
        printResponse(response);
        return response;
    }

    // POST - Create object with custom headers
    public HttpResponse createObject(String url, String payload, String contentType) throws IOException {
        HttpPost post = new HttpPost(url);
        setHeadersAndPayload(post, payload, contentType);
        return executeRequest(post);
    }

    // GET - Read object
    public CloseableHttpResponse getObject(String url) throws IOException {
        return executeRequest(new HttpGet(url));
    }

    // PUT - Update object
    public HttpResponse updateObject(String url, String payload) throws IOException {
        HttpPut put = new HttpPut(url);
        setHeadersAndPayload(put, payload, "application/json");
        return executeRequest(put);
    }

    // PATCH - Update specific fields in an object
    public HttpResponse updateSpecificObject(String url, String payload) throws IOException {
        HttpPatch patch = new HttpPatch(url);
        setHeadersAndPayload(patch, payload, "application/json");
        return executeRequest(patch);
    }

    // DELETE - Delete object
    public HttpResponse deleteObject(String url) throws IOException {
        return executeRequest(new HttpDelete(url));
    }

    // Utility method to set headers and payload
    private void setHeadersAndPayload(HttpEntityEnclosingRequestBase request, String payload, String contentType) throws IOException {
        request.setHeader("Content-Type", contentType);
        request.setEntity(new StringEntity(payload));
    }

    // Method to validate if the response content type is JSON
    public boolean isJsonResponse(HttpResponse response) {
        String contentType = response.getEntity().getContentType().getValue();
        return contentType.contains("application/json");
    }

    // Get status code from the response
    public int getStatusCode(HttpResponse response) {
        return response.getStatusLine().getStatusCode();
    }

    // Utility method to validate status code and content type
    public void validateResponse(CloseableHttpResponse response, int expectedStatusCode) throws IOException {
        // Validate Content-Type
        Assert.assertTrue(isJsonResponse(response), "Content-Type is not JSON.");

        // Validate Status Code
        int actualStatusCode = getStatusCode(response);
        System.out.println("Status Code: " + actualStatusCode);
        Assert.assertEquals(actualStatusCode, expectedStatusCode, "Status code does not match expected.");
    }

    // Utility method to parse response to JSON using Jackson
    public JsonNode parseResponseToJson(CloseableHttpResponse response) throws IOException {
        String responseBody = EntityUtils.toString(response.getEntity(), "UTF-8");
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readTree(responseBody);
    }

    // Print response status and body for debugging
    public void printResponse(CloseableHttpResponse response) throws IOException {
        System.out.println("Status Code: " + getStatusCode(response));
        JsonNode jsonResponse = parseResponseToJson(response);
        System.out.println("Response Body: " + jsonResponse.toString());
    }

    // Close the HTTP client
    public void closeClient() throws IOException {
        client.close();
    }
}