package team1.mvnp2;

import java.io.IOException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;

public class Get_req extends Http_client_library {

    private final Http_client_library common_methods = new Http_client_library();

    @BeforeClass
    public void setUp() {
        // Setup tasks executed before test cases start
        System.out.println("Starting GET Request Tests...");
    }

    @AfterClass
    public void tearDown() {
        try {
            // Close resources, such as HTTP client, after all tests are done
            common_methods.closeClient();
            System.out.println("Finished GET Request Tests...");
        } catch (IOException e) {
            // Handle exception when closing resources
            System.err.println("Error while closing HTTP client: " + e.getMessage());
        }
    }

    // Test 1: Validate all objects are returned, and count matches expected count
    @Test
    public void getAllObjects() {
        try {
            // Step 1: Send GET request
            CloseableHttpResponse response = common_methods.getObject("https://api.restful-api.dev/objects");
            common_methods.validateResponse(response, 200); // Validate response status

            // Step 2: Parse response into JSON
            JsonNode actualJson = common_methods.parseResponseToJson(response);
            Assert.assertTrue(actualJson.isArray(), "Response is not a JSON array.");
            Assert.assertTrue(actualJson.size() > 0, "JSON array should not be empty.");

            // Step 3: Validate object count
            int actualCount = actualJson.size();
            int expectedCount = 13; // Replace with expected object count
            System.out.println("Actual Count: " + actualCount);
            Assert.assertEquals(actualCount, expectedCount, "Mismatch in the number of objects in the response.");
        } catch (IOException e) {
            // Handle IOException during API call
            System.err.println("IOException occurred in getAllObjects: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Catch other unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }

    // Test 2: Validate objects returned with specific IDs
    @Test
    public void getMultipleObjects() {
        try {
            // Step 1: Send GET request with specific IDs
            CloseableHttpResponse response = common_methods.getObject("https://api.restful-api.dev/objects?id=3&id=5&id=1");
            common_methods.validateResponse(response, 200); // Validate response status

            // Step 2: Parse and validate JSON response
            JsonNode actualJson = common_methods.parseResponseToJson(response);
            Assert.assertTrue(actualJson.isArray(), "Response is not a JSON array.");
            Assert.assertEquals(actualJson.size(), 3, "Expected 3 objects in the response.");
            System.out.println("Actual JSON Response: " + actualJson.toString());
        } catch (IOException e) {
            // Handle IOException
            System.err.println("IOException occurred in getMultipleObjects: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Catch unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }

    // Test 3: Validate single object returned with a valid ID
    @Test
    public void getSingleValidObject() {
        try {
            // Step 1: Send GET request with single ID
            CloseableHttpResponse response = common_methods.getObject("https://api.restful-api.dev/objects?id=2");
            common_methods.validateResponse(response, 200); // Validate response status

            // Step 2: Parse and validate JSON response
            JsonNode actualJson = common_methods.parseResponseToJson(response);
            Assert.assertTrue(actualJson.isArray(), "Response is not a JSON array.");
            Assert.assertEquals(actualJson.size(), 1, "Expected 1 object in the response.");
        } catch (IOException e) {
            // Handle IOException
            System.err.println("IOException occurred in getSingleValidObject: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Catch unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }

    // Test 4: Validate handling of query parameters (expected to fail due to unencoded spaces)
    @Test
    public void getObjectWithQP() {
        try {
            // Step 1: Send GET request with unencoded query parameter
            String endpoint = "https://api.restful-api.dev/objects?name=Google Pixel 6 Pro";
            CloseableHttpResponse response = common_methods.getObject(endpoint);
            common_methods.validateResponse(response, 200); // Validate response status

            // Step 2: Parse and validate JSON response
            JsonNode actualJson = common_methods.parseResponseToJson(response);
            Assert.assertTrue(actualJson.isArray(), "Response is not a JSON array.");
            Assert.assertEquals(actualJson.size(), 1, "Expected one object in the response.");
        } catch (IOException e) {
            // Handle IOException
            System.err.println("IOException occurred in getObjectWithQP: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Catch unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }

    // Test 5: Validate behavior when requesting an invalid object
    @Test
    public void getInvalidObject() {
        try {
            // Step 1: Send GET request with invalid ID
            CloseableHttpResponse response = common_methods.getObject("https://api.restful-api.dev/objects/f9866789");
            common_methods.validateResponse(response, 404); // Validate response status

            // Step 2: Log response body for debugging
            String responseBody = response.getEntity() != null
                ? common_methods.parseResponseToJson(response).toString()
                : "No content returned.";
            System.out.println("Response Body: " + responseBody);

            // Step 3: Validate error message
            Assert.assertTrue(responseBody.contains("error"), "Expected error message in the response.");
        } catch (IOException e) {
            // Handle IOException
            System.err.println("IOException occurred in getInvalidObject: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            // Catch unexpected exceptions
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }
 // Test 6: Validate limiting objects count to 5
    
    @Test
    public void getObjectsWithLimit() {
        try {
            // Step 1: Send GET request with limit parameter
            CloseableHttpResponse response = common_methods.getObject("https://api.restful-api.dev/objects?limit=5");
            common_methods.validateResponse(response, 200); // Validate response status
     
            // Step 2: Parse and validate JSON response
            JsonNode actualJson = common_methods.parseResponseToJson(response);
            Assert.assertTrue(actualJson.isArray(), "Response is not a JSON array.");
            Assert.assertEquals(actualJson.size(), 5, "Expected exactly 5 objects in the response.");
     
            System.out.println("Actual JSON Response (Limit 5): " + actualJson.toString());
        } catch (IOException e) {
            System.err.println("IOException occurred in getObjectsWithLimit: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }
     
    // Test 7: Validate paginated response using offset=5
     
    @Test
    public void getObjectsWithOffset() {
        try {
            // Step 1: Send GET request with offset parameter
            CloseableHttpResponse response = common_methods.getObject("https://api.restful-api.dev/objects?offset=5&limit=5");
            common_methods.validateResponse(response, 200); // Validate response status
     
            // Step 2: Parse and validate JSON response
            JsonNode actualJson = common_methods.parseResponseToJson(response);
            Assert.assertTrue(actualJson.isArray(), "Response is not a JSON array.");
            Assert.assertEquals(actualJson.size(), 5, "Expected exactly 5 objects in the response.");
     
            System.out.println("Actual JSON Response (Offset 5, Limit 5): " + actualJson.toString());
        } catch (IOException e) {
            System.err.println("IOException occurred in getObjectsWithOffset: " + e.getMessage());
            Assert.fail("Test failed due to IOException.");
        } catch (Exception e) {
            System.err.println("Unexpected error occurred: " + e.getMessage());
            Assert.fail("Test failed due to unexpected error.");
        }
    }
}
