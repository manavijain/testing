package stepdef;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Utilities.baseclass;
import Utilities.log4jUtil;
import Utilities.screenshot;
import io.cucumber.java.en.Then;

public class productSpecifications extends baseclass  
{
    @Then("the product specifications are fetched")
    public void the_product_specifications_are_fetched()  
    {
        try  
        {
            // Switch to new tab
            for (String windowHandle : dr.getWindowHandles())  
            {
                dr.switchTo().window(windowHandle);
            }
            log4jUtil.info("Switched to new tab successfully.");

            // Fetch specifications section
            WebElement titleElement = dr.findElement(By.xpath("//div[@class='_8tSq3v']"));
            String title = titleElement.getText();
            log4jUtil.info("Fetched section: " + title);

            // Check if 'Read More' button exists
            List<WebElement> readMoreElements = dr.findElements(By.xpath("//button[@class='QqFHMw _4FgsLt']"));
            if (!readMoreElements.isEmpty())  
            {
                WebElement readMoreElement = readMoreElements.get(0);
                readMoreElement.click();
                log4jUtil.info("Clicked 'Read More' button.");
            }
            else  
            {
                log4jUtil.info("'Read More' button not found, fetching directly.");
            }

            // Fetch specification details
            WebElement detailsElement = dr.findElement(By.xpath("//div[@class='_1OjC5I']"));
            String details = detailsElement.getText();
            System.out.println("Specification Details: " + details);  

        }  
        catch (Exception e)  
        { 
        	Hooks.setLastException(e);
            throw e; 
            //log4jUtil.error("Error occurred during fetching product specifications", e);
            //screenshot.captureScreenshot("Failed_Product_Specifications");        	                  
        }
    }
}