package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class baseclass 
{
    public static WebDriver dr;
    configReader config = new configReader();

    public WebDriver launch_edge() 
    {
        String url = config.getProperty("flipkart_url"); // Get URL from properties file
        dr = new EdgeDriver();
        dr.get(url);
        dr.manage().window().maximize();
        return dr;
    }

    public void close_edge() 
    {
        dr.quit();
    }
}
