package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class configReader {

    private Properties properties;
    
    public configReader() 
    {
        properties = new Properties();
        try 
        {
            FileInputStream file = new FileInputStream("src/test/resources/config.properties");
            properties.load(file);
        } 
        catch (IOException e) 
        {
            System.err.println("Unable to load properties file: " + e.getMessage());
        }
    }

    public String getProperty(String key) 
    {
        return properties.getProperty(key);
    }
}